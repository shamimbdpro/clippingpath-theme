<?php 

 // Template Name: pricing 

?>

<?php get_header();?>
  <section id="inner-banner" style="background: url(<?php echo cs_get_option('price')?>) no-repeat center; background-size: cover;">
        <div class="overlay">
            <div class="container">
                <div class="row">
                    <div class="col-12 p-0">
                        <h1><?php the_title();?></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
   <section id="pricing-table" class="hide">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2><span>expert our</span>Pricing table</h2>
                </div>
                <div class="col-12 text-center">
                   <?php echo do_shortcode('[wphtmlblock id="64"]')?>
                </div>
                <div class="col-12 text-center price-request">
                    <p>The above prices are for clipping path service only. If you need any other service<br> please request a quote.</p>
                   <a class="btn-linked" href="#">Request a Quote</a>
                </div>
            </div>
        </div>
    </section>

<?php get_footer();?>