<form action="<?php echo home_url(); ?>" method="get" class="d-md-none d-lg-block">
        <input type="search" class="search" placeholder="enter Search" name="s" value="<?php the_search_query(); ?>" required>
         <button type="submit"><i class="fa fa-search"></i></button>
 </form>                     