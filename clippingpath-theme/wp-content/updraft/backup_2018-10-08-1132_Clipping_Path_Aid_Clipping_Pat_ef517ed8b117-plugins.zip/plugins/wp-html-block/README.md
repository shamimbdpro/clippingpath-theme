# [WP HTML Block](http://phpprogrammernepal.com/wp-html-block/)

WP HTML Block help you to create HTML Block so that you can insert it to any place like page, post, custom post type, widget etc via shortcode.

As per your need, you can modify the output so that you can decide if title, description or image displays and also an alignments. WP HTML Block provides you a really simple way to add third pary code like PayPal donation buttons, iFrames etc. You will get separate shortcode for each HTML Block you create.


## Documentation
* [WP HTML Block Documentation](http://phpprogrammernepal.com/wp-html-block/)
* [WP HTML Block Support](http://phpprogrammernepal.com/say-hello/)

## Support
Please don't use our issue tracker for support requests, but for WP HTML Block issues only. For support, go to [WP HTML Block support](http://phpprogrammernepal.com/wp-html-block/) page.

Support requests in issues on this repository will be closed on sight.